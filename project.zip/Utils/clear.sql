
--Clear existing data
DELETE FROM hospital;
DELETE FROM hospital_payment;
DELETE FROM hospital_comp;
DELETE FROM city;
DELETE FROM payment;
DELETE FROM complication;
DELETE FROM time_range;