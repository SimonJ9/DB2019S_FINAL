import pandas.io.sql as psql
import psycopg2 as pg
import Utils

def timeRange_query():
    print(Utils.conStr)